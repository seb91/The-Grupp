How to run:

1.Install java 1.8.
2. Double click SidescrollerDemo.jar alternatively run "java -jar SideScrollerDemo.jar" in the command prompt. 
    

The program should run and can be turned of by pressing the quit button, pressing escape when in the main menu or by pressing the cross in the upper right corner.